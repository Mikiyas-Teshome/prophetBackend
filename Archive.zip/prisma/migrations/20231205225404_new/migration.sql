-- DropIndex
DROP INDEX `purchaseReferences_packageId_key` ON `purchaseReferences`;

-- DropIndex
DROP INDEX `subscriptions_packageId_key` ON `subscriptions`;
