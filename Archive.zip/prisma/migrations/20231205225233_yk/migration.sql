-- DropForeignKey
ALTER TABLE `purchaseReferences` DROP FOREIGN KEY `purchaseReferences_packageId_fkey`;

-- DropForeignKey
ALTER TABLE `subscriptions` DROP FOREIGN KEY `subscriptions_packageId_fkey`;
