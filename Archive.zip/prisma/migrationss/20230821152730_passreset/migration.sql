-- AlterTable
ALTER TABLE "users" ADD COLUMN     "isPassResetEnabled" BOOLEAN NOT NULL DEFAULT false;
