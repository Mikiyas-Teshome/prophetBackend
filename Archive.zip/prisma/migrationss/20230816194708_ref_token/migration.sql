-- AlterTable
ALTER TABLE "users" ADD COLUMN     "refreshToken" TEXT;
