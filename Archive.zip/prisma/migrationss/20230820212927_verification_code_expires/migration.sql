-- AlterTable
ALTER TABLE "users" ADD COLUMN     "verificationCodeExpiresAt" TIMESTAMP(3);
