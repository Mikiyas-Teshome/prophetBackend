/*
  Warnings:

  - You are about to alter the column `publicRow` on the `Tip` table. The data in that column could be lost. The data in that column will be cast from `BigInt` to `Integer`.

*/
-- AlterTable
ALTER TABLE "Tip" ALTER COLUMN "publicRow" SET DATA TYPE INTEGER;
