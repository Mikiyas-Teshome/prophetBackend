-- AlterEnum
ALTER TYPE "Providers" ADD VALUE 'PHONE';
