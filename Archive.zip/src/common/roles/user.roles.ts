export enum UserRoles {
  UnsubscribedUser = 'unsubscribed_user',
  AdFreeSubscribed = 'ad_free_user',
  MonthlySubscribedUser = 'monthly_subscribed_user',
  Admin = 'admin',
}
